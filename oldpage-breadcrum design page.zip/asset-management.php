<!DOCTYPE html>
<html lang="zxx" class="theme-light">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>A4R INFRA :: Asset Management</title>

  <link rel="icon" type="image/png" href="assets/img/favicon.png">
  <?php include('inc/css.php') ?>
</head>

<body data-spy="scroll" data-offset="70">
  <?php include('inc/header.php') ?>
  <div class="braeamcode" style="background-image:url('./assets/img/img/bremcode.jpg')">
  </div>
  <section class="py-5">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-lg-6">
          <div class="advisor-img" data-aos="fade-up-right" data-aos-duration="2000" data-aos-dealay=" 3000"
            data-aos-easing="ease-in-sine">
            <div class="advisor-content" data-aos="fade-left" data-aos-duration="2000" data-aos-dealay=" 3000"
              data-aos-easing="ease-in-sine">
              <h2 class="pb-4 m_heading">Asset Management</h2>
              <p class="pb-1" style="text-align: justify;">Highways and bridges keep people and goods moving. Good
                management reduces surprises,
                avoids frequent breakdowns, and keeps corridors open, safe, and reliable.</p>

              <p class="pb-1" style="text-align: justify;">Asset management is about taking care of roads, bridges, and
                roadside systems from day one
                till the end of their service life. We make sure they work well every day, stay safe, and last longer,
                while keeping the total cost under control.
              <p>
              <p class="pb-1" style="text-align: justify;">We look after highway assets end-to-end—build, operate,
                maintain, and renew, so they
                deliver high performance at the lowest long-term cost. Some of our scope includes:</p>
            </div>
          </div>
        </div>
        <div class="col-lg-6">
          <!-- features start -->
          <!-- card 1 -->
          <div class="feature-card">
            <p class="toggle-title" onclick="toggleContent(this)"> Listing and checking assets</p>
            <div class="toggle-content">
              <p>Make a complete register and do condition checks for pavement, structures, drains, lighting, signage,
                and safety barriers.</p>
            </div>
          </div>

          <!-- card 2 -->
          <div class="feature-card">
            <p class="toggle-title" onclick="toggleContent(this)"> Scoring defects and risks</p>
            <div class="toggle-content">
              <p>Rank issues by impact and urgency; create a clear “fix now / fix soon / plan later” list.</p>
            </div>
          </div>
          <!-- card 3 -->
          <div class="feature-card">
            <p class="toggle-title" onclick="toggleContent(this)">Planning budgets</p>
            <div class="toggle-content">
              <p>Prepare annual plans and 3–5 year programs for routine, periodic, and renewal works.</p>
            </div>
          </div>
          <!-- card 4 -->
          <div class="feature-card">
            <p class="toggle-title" onclick="toggleContent(this)"> Using digital tools</p>
            <div class="toggle-content">
              <p>Keep digital registers, GIS maps, and easy dashboards to track locations, quantities, progress, and
                costs.</p>
            </div>
          </div>
          <!-- card 5 -->
          <div class="feature-card">
            <p class="toggle-title" onclick="toggleContent(this)"> Ensuring compliance</p>
            <div class="toggle-content">

              <p>Maintain audit-ready records aligned with MoRTH/IRC/NHAI and client requirements.</p>
            </div>
          </div>


          <!-- features end -->
          <script>
            function toggleContent(element) {
              const content = element.nextElementSibling;
              if (content.style.display === "none" || content.style.display === "") {
                content.style.display = "block";
              } else {
                content.style.display = "none";
              }
            }
          </script>

        </div>
      </div>
    </div>
  </section>


  <section class="work bg-dark text-dark">
    <div class="container">
      <h2 class="pb-4 m_heading text-center">How we Work</h2>
      <div class="row">
        <div class="col-lg-4 col-sm-6">
          <div class="work_page">
            <h3>Catalogue</h3>
            <p>Build a full asset list with unique IDs and GPS/GIS locations.</p>
          </div>
        </div>
        <div class="col-lg-4 col-sm-6">
          <div class="work_page">
            <h3>Survey</h3>
            <p>Inspect on site; record condition, photos, and measurements.</p>
          </div>
        </div>
        <div class="col-lg-4 col-sm-6">
          <div class="work_page">
            <h3>Analyse</h3>
            <p>Score defects and risk; set service levels and response times.</p>
          </div>
        </div>
        <div class="col-lg-4 col-sm-6">
          <div class="work_page">
            <h3>Program</h3>
            <p>Prioritise works; schedule methods, traffic plans, and timelines.</p>
          </div>
        </div>
        <div class="col-lg-4 col-sm-6">
          <div class="work_page">
            <h3>Budget & Deliver</h3>
            <p>Finalise yearly and multi-year budgets; execute and supervise.</p>
          </div>
        </div>
        <div class="col-lg-4 col-sm-6">
          <div class="work_page">
            <h3 ></h3>Review & Improve</h3>
            <p>Track KPIs on dashboards; audit, learn, and update plans.</p>
          </div>
        </div>
        <div class="col-lg-12 col-sm-12">
          <div class="work_page">
            <h3>Results in:</h3>
              <div class="row">
                <div class="col-4">
                   <ul class="order-item">
                  <li>Safer corridors</li>
                   </ul>
                </div>
                  <div class="col-4">
                   <ul class="order-item">
                  <li>Ride quality</li>
                   </ul>
                </div>
                  <div class="col-4">
                   <ul class="order-item">
                   <li>Lower life-cycle cost</li>
                   </ul>
                </div>
                  <div class="col-4">
                   <ul class="order-item">
                  <li>Stronger compliance</li>
                   </ul>
                </div>
                 <div class="col-4">
                   <ul class="order-item">
                  <li>Clean audits</li>
                   </ul>
                </div>
              </div>
          </div>
        </div>
      </div>
    </div>
  </section>


  <section class="py-5">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-lg-12">
          <div class="text_d">
            <h2 class="pb-4 m_heading">List of Inventory/Machinery/Equipment Manage by us</h2>
          </div>
          <div class="table">


            <table border="0" width="100%" cellspacing="0" cellpadding="0">
              <thead>
                <tr>
                  <th width="133" height="19">S. NO</th>
                  <th width="217">Description</th>
                  <th width="118">Nos</th>
                </tr>
                <thead>
                <tbody>
                  <tr>
                    <td height="19">1</td>
                    <td>Hydraulic Excavators</td>
                    <td>4</td>
                  </tr>
                  <tr>
                    <td height="19">2</td>
                    <td>Backhoe Loaders</td>
                    <td>4</td>
                  </tr>
                  <tr>
                    <td height="19">3</td>
                    <td>Motor Graders</td>
                    <td>4</td>
                  </tr>
                  <tr>
                    <td height="19">4</td>
                    <td>Wheel Loaders</td>
                    <td>4</td>
                  </tr>
                  <tr>
                    <td height="19">5</td>
                    <td>Tippers / Dumpers</td>
                    <td>34</td>
                  </tr>
                  <tr>
                    <td height="19">6</td>
                    <td>Soil Compactors</td>
                    <td>3</td>
                  </tr>
                  <tr>
                    <td height="19">7</td>
                    <td>Tandem Rollers</td>
                    <td>5</td>
                  </tr>
                  <tr>
                    <td height="19">8</td>
                    <td>Pneumatic Tyred Rollers (PTR)</td>
                    <td>2</td>
                  </tr>
                  <tr>
                    <td height="19">9</td>
                    <td>Vibratory Plate Compactors</td>
                    <td>4</td>
                  </tr>
                  <tr>
                    <td height="19">10</td>
                    <td>Wet Mix Macadam (WMM) Plant</td>
                    <td>2</td>
                  </tr>
                  <tr>
                    <td height="19">11</td>
                    <td>Asphalt (Hot Mix) Plant</td>
                    <td>3</td>
                  </tr>
                  <tr>
                    <td height="19">12</td>
                    <td>Drum Mix Plant with RAP Facility</td>
                    <td>2</td>
                  </tr>
                  <tr>
                    <td height="19">13</td>
                    <td>Sensor Paver Finisher (Asphalt Paver)</td>
                    <td>3</td>
                  </tr>
                  <tr>
                    <td height="19">14</td>
                    <td>Concrete Paver (Slip-form)</td>
                    <td>2</td>
                  </tr>
                  <tr>
                    <td height="19">15</td>
                    <td>Bitumen Sprayer / Distributor</td>
                    <td>3</td>
                  </tr>
                  <tr>
                    <td height="19">16</td>
                    <td>Mechanical Broom / Road Sweeper</td>
                    <td>6</td>
                  </tr>
                  <tr>
                    <td height="19">17</td>
                    <td>Truck Mounted Crane (25T / 75T / 100T)</td>
                    <td>3</td>
                  </tr>
                  <tr>
                    <td height="19">18</td>
                    <td>Batching Plant (30–60 Cum/hr)</td>
                    <td>3</td>
                  </tr>
                  <tr>
                    <td height="19">19</td>
                    <td>Transit Mixer</td>
                    <td>9</td>
                  </tr>
                  <tr>
                    <td height="19">20</td>
                    <td>Road Marking Machine (Thermoplastic / Paint)</td>
                    <td>3</td>
                  </tr>
                  <tr>
                    <td height="19">21</td>
                    <td>Kerb Casting Machine</td>
                    <td>2</td>
                  </tr>
                  <tr>
                    <td height="19">22</td>
                    <td>Water Tankers</td>
                    <td>12</td>
                  </tr>
                  <tr>
                    <td height="19">23</td>
                    <td>Tractor Trolleys</td>
                    <td>9</td>
                  </tr>
                  <tr>
                    <td height="19">24</td>
                    <td>Pick-ups & Utility Vehicles (Bolero Camper, etc.)</td>
                    <td>28</td>
                  </tr>
                  <tr>
                    <td height="19">25</td>
                    <td>Ambulance (as per NHAI norms)</td>
                    <td>4</td>
                  </tr>
                  <tr>
                    <td height="19">26</td>
                    <td>Patrol Vehicle (as per NHAI norms)</td>
                    <td>4</td>
                  </tr>
                  <tr>
                    <td height="19">27</td>
                    <td>Diesel Generator Sets (DG Sets)</td>
                    <td>7</td>
                  </tr>
                  <tr>
                    <td height="19">28</td>
                    <td>Total Station</td>
                    <td>2</td>
                  </tr>
                  <tr>
                    <td height="19">29</td>
                    <td>Field Lab Equipment</td>
                    <td>As per requirement</td>
                  </tr>
                </tbody>
            </table>

          </div>
        </div>

      </div>
    </div>
  </section>

  <!-- end -->


  <?php include('inc/footer.php') ?>
</body>

</html>